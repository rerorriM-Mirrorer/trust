local DisposeBag = require('cylibs/events/dispose_bag')
local Keyboard = require('cylibs/ui/input/keyboard')
local SoundTheme = require('cylibs/sounds/sound_theme')
local FocusManager = require('cylibs/ui/focus/focus_manager')
local MenuView = require('cylibs/ui/menu/menu_view')

local Menu =  {}
Menu.__index = Menu
Menu.__type = "Menu"


function Menu.new(contentViewStack, viewStack, infoView, mediaPlayer, soundTheme)
    local self = setmetatable({}, Menu)

    self.buttonHeight = 16
    self.isChatOpen = false
    self.disposeBag = DisposeBag.new()
    self.menuItemStack = L{}

    self.contentViewStack = contentViewStack
    self.viewStack = viewStack
    self.infoView = infoView
    self.mediaPlayer = mediaPlayer
    self.soundTheme = soundTheme

    self.disposeBag:addAny(L{ self.viewStack })

    self.disposeBag:add(viewStack:onStackSizeChanged():addAction(function(stackSize)
        if stackSize > 0 then
            Keyboard.input():setMenuNavigationActive(true)
            self.infoView:setVisible(true)
            self.infoView:layoutIfNeeded()
        end
    end), viewStack:onStackSizeChanged())

    self.disposeBag:add(viewStack:onEmpty():addAction(function(_)
        Keyboard.input():setMenuNavigationActive(false)
        self.infoView:setVisible(false)
        self.infoView:layoutIfNeeded()
    end
    ), viewStack:onEmpty())

    Keyboard.input():on_chat_toggle():addAction(function(_, isChatOpen)
        if self.isChatOpen == isChatOpen then
            return
        end
        self.isChatOpen = isChatOpen

        Keyboard.input():refreshMenuBindings()
    end)

    return self
end

function Menu:destroy()
    Keyboard.input():setMenuNavigationActive(false)
    self.disposeBag:destroy()
end

function Menu:showMenu(menuItem)
    -- Keep-view child pickers are part of the same edit. Other navigation is
    -- an intentional departure and must finish a valid options draft first.
    if self.menuView and self.menuView:getItem() ~= menuItem and not menuItem.keepViews
            and not self:commitCurrentEditor() then return false end
    if self.menuItemStack:contains(menuItem) then
        while self.menuItemStack:length() > 0 and self.menuItemStack[self.menuItemStack:length()]:getUUID() ~= menuItem:getUUID() do
            self.menuItemStack:remove(self.menuItemStack:length())
        end
    else
        self.menuItemStack:append(menuItem)
    end

    if not self.menuView then
        self.menuView = MenuView.new(menuItem, self.contentViewStack, self.infoView, function(menuItem) self:showMenu(menuItem) end, self.mediaPlayer)
        self.menuView:getDelegate():didSelectItemAtIndexPath():addAction(function(indexPath)
            self.menuView:getDelegate():deselectAllItems()

            local textItem = self.menuView:getDataSource():itemAtIndexPath(indexPath):getTextItem()

            -- Mouse activation can skip the keyboard focus-return path.
            -- Explicit Confirm/Save retain their original action semantics.
            if not L{'Confirm', 'Save', 'Reset', 'Clear', 'Clear All', 'Delete', 'Import'}:contains(textItem:getText())
                    and not self:commitCurrentEditor() then return end

            local currentView = self.contentViewStack:getCurrentView()
            if currentView and type(currentView.onSelectMenuItemAtIndexPath) == 'function' then
                if currentView:onSelectMenuItemAtIndexPath(textItem, indexPath) == false then return end
            end

            local childMenuItem = self.menuView:getItem():getChildMenuItem(textItem:getText())
            if childMenuItem then
                local isEnabled, errorMessage = childMenuItem:isEnabled()
                if not isEnabled then
                    self.mediaPlayer:playSound(self.soundTheme:getSoundForAction(SoundTheme.UI.Menu.Error))
                    addon_system_message(errorMessage or "Unable to perform this action.")
                    return
                end
                if type(childMenuItem) == 'function' then
                    childMenuItem()
                    return
                end
                if childMenuItem:getAction() ~= nil then
                    childMenuItem:getAction()(self)
                    return
                end
                if childMenuItem:getButtonItems():length() > 0 then
                    self:showMenu(childMenuItem)
                else
                    local menuArgs = {}
                    local currentView = self.viewStack:getCurrentView()
                    if currentView then
                        menuArgs = currentView and type(currentView.getMenuArgs) == 'function' and currentView:getMenuArgs()
                    end
                    local contentView = childMenuItem:getContentView(menuArgs, self.infoView, self.mediaPlayer, self.soundTheme)
                    if contentView then
                        self.menuView.views:append(contentView)
                        self.contentViewStack:present(contentView)
                        if contentView:hasFocus() then
                            self.menuView:setHasFocus(false)
                        end
                    end
                end
            end
        end)
        self.menuView:getDelegate():didMoveCursorToItemAtIndexPath():addAction(function(indexPath)
            self:onMoveCursorToIndexPath(indexPath)
        end)
    else
        self.menuView:setItem(menuItem)
    end

    local cursorIndexPath = self.menuView:getDelegate():getCursorIndexPath()
    self:onMoveCursorToIndexPath(cursorIndexPath)

    if self.viewStack:isEmpty() then
        self.viewStack:present(self.menuView)
        self.menuView:requestFocus()
        self.mediaPlayer:playSound(self.soundTheme:getSoundForAction(SoundTheme.UI.Menu.Open))
    end

    self:requestFocus()
end

function Menu:commitCurrentEditor()
    local view = self.contentViewStack:getCurrentView()
    if view and view.commitOnExit and not view:commitOnExit() then
        view:requestFocus()
        return false
    end
    return true
end

function Menu:updateInfoView(menuItem, parentMenuItem)
    local parentTitleText = parentMenuItem:getTitleText() or ""
    local parentDescriptionText = parentMenuItem:getDescriptionText() or ""
    if menuItem and type(menuItem) ~= 'function' then
        local titleText = menuItem:getTitleText() or parentTitleText
        local descriptionText = menuItem:getDescriptionText() or parentDescriptionText
        self.infoView:setTitle(titleText)
        self.infoView:setDescription(descriptionText)
    else
        self.infoView:setTitle(parentTitleText)
        self.infoView:setDescription(parentDescriptionText)
    end
end

function Menu:onMoveCursorToIndexPath(cursorIndexPath)
    local textItem = self.menuView:getDataSource():itemAtIndexPath(cursorIndexPath):getTextItem()
    local childMenuItem = self.menuView:getItem():getChildMenuItem(textItem:getText())
    self:updateInfoView(childMenuItem, self.menuView:getItem())
end

function Menu:playSoundsForKey(keyName)
    if keyName == 'Enter' then
        self.mediaPlayer:playSound(self.soundTheme:getSoundForAction(SoundTheme.UI.Menu.Enter))
    elseif keyName == 'Escape' then
        self.mediaPlayer:playSound(self.soundTheme:getSoundForAction(SoundTheme.UI.Menu.Escape))
    elseif S{ 'Up', 'Down', 'Left', 'Right' }:contains(keyName) then
        self.mediaPlayer:playSound(self.soundTheme:getSoundForAction(SoundTheme.UI.Menu.Cursor))
    end
end

function Menu:onKeyboardEvent(key, pressed, flags, blocked)
    if windower.ffxi.get_info().chat_open or blocked then
        return blocked
    end
    if pressed then
        local keyName = Keyboard.input():getKey(key, flags)

        self:playSoundsForKey(keyName)

        if keyName == 'Left' then
            local currentView = self.contentViewStack:getCurrentView()
            if currentView and currentView:shouldRequestFocus() then
                currentView:requestFocus()
            else
                self.menuView:pageLeft()
            end
        elseif keyName == 'Right' then
            local currentView = self.contentViewStack:getCurrentView()
            if currentView and currentView:hasFocus() then
                if self:commitCurrentEditor() then currentView:resignFocus() end
            else
                self.menuView:pageRight()
            end
        elseif keyName == 'Escape' then
            if not self:commitCurrentEditor() then return true end
            if self.menuItemStack:length() > 1 then
                local removed = self.menuItemStack:remove(self.menuItemStack:length())
                self.menuView:setItem(self.menuItemStack[self.menuItemStack:length()])
                if removed then
                    removed:setMenuIndex(nil)
                end
            else
                self.viewStack:dismiss()
                self.menuItemStack = L{}
                self.menuView = nil
                FocusManager.shared():resignAllFocus()
            end
        else
            local currentView = self.viewStack:getCurrentView()
            if currentView then
                currentView:onKeyboardEvent(key, pressed, flags, blocked)
            end
        end
    end
    return L{1,203,205}:contains(key)
end

function Menu:closeAll(discardDrafts)
    if not discardDrafts and not self:commitCurrentEditor() then return false end
    local isMenuShown = self:isVisible()

    if self.menuView then
        self.menuView:destroy()
        self.menuView = nil
    end
    self.menuItemStack = L{}
    self.viewStack:dismissAll()

    if isMenuShown then
        FocusManager.shared():resignAllFocus()
    end
    return true
end

function Menu:isVisible()
    return not self.menuItemStack:empty()
end

---
-- Returns whether the view should resign focus if it currently has focus.
--
-- @treturn boolean If the view should resign focus.
function Menu:shouldResignFocus()
    return self.resignFocus
end

---
-- Resigns focus from the view.
--
function Menu:resignFocus()
    FocusManager.shared():resignFocus(self)
end

---
-- Request focus for the view.
--
-- @treturn boolean True if the view is focused.
function Menu:requestFocus()
    return FocusManager.shared():requestFocus(self)
end

---
-- Returns whether the view has focus.
--
-- @treturn boolean If the view has focus.
function Menu:hasFocus()
    return self.focused
end

---
-- Sets whether the view has focus.
--
-- @tparam boolean hasFocus Whether the view has focus.
--
function Menu:setHasFocus(hasFocus)
    self.focused = hasFocus

    local currentView = self.viewStack:getCurrentView()
    if currentView then
        currentView:setHasFocus(hasFocus)
    end
end

return Menu
