local CommandMessage = require('cylibs/messages/command_message')
local command_feedback = require('cylibs/util/command_feedback')
local PickerConfigItem = require('ui/settings/editors/config/PickerConfigItem')
local TrustCommands = require('cylibs/trust/commands/trust_commands')
local FollowTrustCommands = setmetatable({}, {__index = TrustCommands })
FollowTrustCommands.__index = FollowTrustCommands
FollowTrustCommands.__class = "FollowTrustCommands"

function FollowTrustCommands.new(trust, action_queue)
    local self = setmetatable(TrustCommands.new(), FollowTrustCommands)

    self.trust = trust
    self.action_queue = action_queue

    local party_member_names = trust:get_party():get_party_members(true):map(function(p) return p:get_name() end)

    self:add_command('default', self.handle_follow_party_member, 'Follow a player', L{ PickerConfigItem.new('party_member_name', party_member_names[1], party_member_names, nil, "Party Member Name"), })

    trust:get_party():on_party_members_changed():addAction(function(party_members)
        local party_member_names = party_members:map(function(p) return p:get_name() end)

        self:add_command('default', self.handle_follow_party_member, 'Follow a player', L{ PickerConfigItem.new('party_member_name', party_member_names[1], party_member_names, nil, "Party Member Name") })
    end)

    self:add_command('me', self.handle_follow_me, 'Make all players follow me')
    self:add_command('start', self.handle_start, 'Resume following')
    self:add_command('stopall', self.handle_stop_all, 'Pause following for all players')
    self:add_command('stop', self.handle_stop, 'Pause following')
    self:add_command('clear', self.handle_clear, 'Clear the follow target')
    self:add_command('distance', self.handle_set_follow_distance, 'Set the follow distance', L{ ConfigItem.new('distance', 0, 50, 1, function(value) return value.." yalms" end, "Target Distance"), })

    return self
end

function FollowTrustCommands:get_command_name()
    return 'follow'
end

function FollowTrustCommands:get_follower()
    return self.trust:role_with_type("follower")
end

-- // trust follow me
function FollowTrustCommands:handle_follow_me()
    local success
    local message

    if L{'All', 'Send'}:contains(state.IpcMode.value) then
        self:get_follower():set_follow_target(nil)
        local quiet_flag = command_feedback.is_quiet() and ' --quiet' or ''
        IpcRelay.shared():send_message(CommandMessage.new('trust follow '..windower.ffxi.get_player().name..quiet_flag))
        success = true
        message = 'Follow set to me on everyone else'
    else
        success = false
        message = 'IpcMode must be set to All or Send to use this command'
    end

    return success, message
end

-- // trust follow party_member_name
function FollowTrustCommands:handle_follow_party_member(party_member_name)
    local success
    local message

    party_member_name = party_member_name:gsub("^%l", string.upper)

    if self:get_follower():is_valid_target(party_member_name) then
        self:handle_set_mode('AutoFollowMode', 'Always', command_feedback.is_quiet())

        local error_message = self:get_follower():follow_target_named(party_member_name)
        if error_message then
            success = false
            message = error_message
        else
            success = true
            message = 'Now following '..party_member_name
        end
    else
        success = false
        message = party_member_name..' is not a valid party member or is not in range'
    end

    return success, message
end

-- // trust follow distance number
function FollowTrustCommands:handle_set_follow_distance(_, distance)
    local success
    local message

    if distance:match("^%d+$") then
        distance = tonumber(distance)
        self:get_follower():set_distance(distance)
        success = true
        message = 'Follow distance set to '..distance
    else
        success = false
        message = 'Invalid distance '..distance
    end

    return success, message
end

-- // trust follow start
function FollowTrustCommands:handle_start()
    local success = true
    local message = 'Following resumed'

    self:get_follower():start_following()

    return success, message
end

-- // trust follow stop
function FollowTrustCommands:handle_stop()
    local success = true
    local message = 'Following paused'

    self:get_follower():stop_following()

    return success, message
end

-- // trust follow clear
function FollowTrustCommands:handle_clear()
    local success = true
    local message = 'Follow target cleared'

    self:get_follower():set_follow_target(nil)

    return success, message
end

-- // trust follow stopall
function FollowTrustCommands:handle_stop_all()
    local success
    local message

    if L{'All', 'Send'}:contains(state.IpcMode.value) then
        IpcRelay.shared():send_message(CommandMessage.new('trust set AutoFollowMode Off'))
        success = true
        message = 'Follow disabled on everyone else'
    else
        success = false
        message = 'IpcMode must be set to All or Send to use this command'
    end

    return success, message
end

return FollowTrustCommands
