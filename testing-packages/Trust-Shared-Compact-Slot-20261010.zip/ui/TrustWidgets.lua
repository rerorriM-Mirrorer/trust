local Frame = require('cylibs/ui/views/frame')
local WidgetManager = require('ui/widgets/WidgetManager')

local View = require('cylibs/ui/views/view')
local TrustWidgets = setmetatable({}, {__index = View })
TrustWidgets.__index = TrustWidgets


function TrustWidgets.new(actionQueue, addonEnabled, trust, mediaPlayer, soundTheme)
    local self = setmetatable(View.new(), TrustWidgets)

    self.actionQueue = actionQueue
    self.addonEnabled = addonEnabled
    self.mediaPlayer = mediaPlayer
    self.soundTheme = soundTheme
    self.trust = trust
    self.widgetManager = WidgetManager.new()

    self:init()

    return self
end

function TrustWidgets:init()
    local TrustStatusWidget = require('ui/widgets/TrustStatusWidget')
    local trustStatusWidget = TrustStatusWidget.new(Frame.new(40, 324, 125, 69), self.addonEnabled, self.actionQueue, player.main_job_name, player.sub_job_name, self.trust:get_party():get_player())
    self.widgetManager:addWidget(trustStatusWidget, "trust")

    local TargetWidget = require('ui/widgets/TargetWidget')
    local targetWidget = TargetWidget.new(Frame.new(40, 496, 125, 40), self.trust:get_party(), self.trust)
    self.widgetManager:addWidget(targetWidget, "target")

    local PartyStatusWidget = require('ui/widgets/PartyStatusWidget')
    local partyStatusWidget = PartyStatusWidget.new(Frame.new(40, 397, 125, 55), self.trust:get_alliance(), self.trust:get_party(), self.trust, self.mediaPlayer, self.soundTheme)
    self.widgetManager:addWidget(partyStatusWidget, "party")

    -- One shared compact presentation and draggable surface. These widgets
    -- keep their tracking and Full-mode views, but their compact overlays are
    -- supplied to Trust rather than separately positioned/drawn.
    partyStatusWidget:setCompactHost(trustStatusWidget)
    targetWidget:setCompactHost(trustStatusWidget)

    for widget in self.widgetManager:getAllWidgets():it() do
        self:addSubview(widget)
    end
    
    for trust in L{ self.trust }:it() do
        coroutine.schedule(function()
            local widget, widgetName = trust:get_widget()
            if widget and widgetName then
                self:addWidget(widget, widgetName)
            end
        end, 0.5)
    end
end

function TrustWidgets:addWidget(widget, widgetName)
    self.widgetManager:addWidget(widget, widgetName)
    self:addSubview(widget)
end

function TrustWidgets:getWidget(widgetName)
    return self.widgetManager:getWidget(widgetName)
end

function TrustWidgets:removeWidget(widgetName)
    self.widgetManager:removeWidget(widgetName)
end

function TrustWidgets:hitTest(x, y)
    for widget in self.widgetManager:getAllWidgets():it() do
        if widget:hitTest(x, y) then
            return true
        end
    end
    return false
end

return TrustWidgets