local CommandMessage = require('cylibs/messages/command_message')
local party_util = require('cylibs/util/party_util')

local TrustCommands = require('cylibs/trust/commands/trust_commands')
local GeneralTrustCommands = setmetatable({}, {__index = TrustCommands })
GeneralTrustCommands.__index = GeneralTrustCommands
GeneralTrustCommands.__class = "GeneralTrustCommands"

function GeneralTrustCommands.new(trust, action_queue, addon_enabled, trust_mode_settings, main_trust_settings, sub_trust_settings)
    local self = setmetatable(TrustCommands.new(), GeneralTrustCommands)

    self.trust = trust
    self.action_queue = action_queue
    self.addon_enabled = addon_enabled
    self.trust_mode_settings = trust_mode_settings
    self.main_trust_settings = main_trust_settings
    self.sub_trust_settings = sub_trust_settings
    self.hud = hud

    -- General
    self:add_command('version', self.handle_version, 'Trust version')
    self:add_command('help', self.handle_help, 'Learn more on the wiki')
    self:add_command('commands', self.handle_command_list, 'See all Trust commands')
    self:add_command('debug', self.handle_debug, 'Show debug info')
    self:add_command('timeout', self.handle_timeout, 'Unload Trust after a specified number of minutes, // trust timeout num_minutes or // trust timeout clear')
    self:add_command('item', self.handle_use_item, 'Use an item by name, // trust item item_name')

    -- State
    self:add_command('start', self.handle_start, 'Start Trust')
    self:add_command('startall', self.handle_start_all, 'Start Trust on all characters, or only party members with // trust startall party')
    self:add_command('stop', self.handle_stop, 'Stop Trust')
    self:add_command('stopall', self.handle_stop_all, 'Stop Trust on all characters, or only party members with // trust stopall party')
    self:add_command('toggle', self.handle_toggle, 'Toggle Trust On and Off')
    self:add_command('reload', self.handle_reload, 'Reload job settings files')
    self:add_command('status', self.handle_status, 'View Trust status')
    self:add_command('widget', self.handle_widget, 'Set widget appearance: // trust widget [full|compact|toggle] [all|trust|party|target]')

    -- Modes
    self:add_command('set', self.handle_set_mode, 'Set a mode to a given value, // trust set mode_name mode_value')
    self:add_command('cycle', self.handle_cycle_mode, 'Cycle the value of a mode, // trust cycle mode_name')
    self:add_command('load', self.handle_load_set, 'Load a mode set, // trust load mode_set_name')
    self:add_command('save', self.handle_save_set, 'Save changes to the current mode set or new set, // trust save mode_set_name (optional)')

    return self
end

function GeneralTrustCommands:get_command_name()
    return 'default'
end

function GeneralTrustCommands:get_all_commands()
    local result = L{}
    for command_name, command in pairs(self.commands) do
        result:append('// trust '..command_name)
    end
    return result
end

-- // trust version
function GeneralTrustCommands:handle_version()
    local success = true
    local message

    addon_system_message("Trust v".._addon.version..".")

    return success, message
end

-- // trust help
function GeneralTrustCommands:handle_help()
    local success = true
    local message

    local jobNameShort = self.trust:get_job().jobNameShort
    if jobNameShort then
        local job = res.jobs:with('ens', jobNameShort)
        local url_suffix = job.en:gsub(" ", "-")
        windower.open_url(addon_settings:getSettings().help.wiki_base_url..'/'..url_suffix)
    else
        windower.open_url(addon_settings:getSettings().help.wiki_base_url)
    end

    return success, message
end

-- // trust version
function GeneralTrustCommands:handle_command_list()
    local success = true
    local message

    hud:openMenu(hud:getMainMenuItem():getChildMenuItem('Commands'))

    return success, message
end

-- // trust status
function GeneralTrustCommands:handle_status()
    local success = true
    local message

    local statuses = L{}
    for key,var in pairs(state) do
        statuses:append(key..': '..var.value)
    end
    statuses:sort()

    for status in statuses:it() do
        addon_message(207, status)
    end

    if player.party:get_assist_target() then
        addon_message(209, 'Assisting '..player.party:get_assist_target():get_name())
    end

    return success, message
end

-- // trust widget [full|compact|toggle] [all|trust|party|target]
-- The visual mode is independent of automation; Target.expanded still controls
-- debuff rows in Full mode, so use compactMode for all three widgets.
function GeneralTrustCommands:handle_widget(_, mode, scope)
    mode = mode or 'toggle'
    scope = scope or 'all'
    if type(mode) ~= 'string' or type(scope) ~= 'string' then
        return false, 'Usage: // trust widget [full|compact|toggle] [all|trust|party|target]'
    end
    mode, scope = mode:lower(), scope:lower()
    if not S{ 'full', 'compact', 'toggle' }:contains(mode)
            or not S{ 'all', 'trust', 'party', 'target' }:contains(scope) then
        return false, 'Usage: // trust widget [full|compact|toggle] [all|trust|party|target]'
    end

    local names = scope == 'all' and L{ 'trust', 'party', 'target' } or L{ scope }
    -- All-mode toggle follows Trust's current presentation so it reunifies
    -- widgets even if individual icon clicks expanded just one of them.
    local reference = windower.trust.ui.get_widget(scope == 'all' and 'trust' or scope)
    local compact = mode == 'compact' or (mode == 'toggle' and reference and not reference.compactMode)
    for name in names:it() do
        local widget = windower.trust.ui.get_widget(name)
        if not widget or not widget.setCompactMode then
            return false, name..' widget is unavailable'
        end
        widget:setCompactMode(compact)
    end
    return true, 'Widget appearance: '..mode..' ('..scope..')'
end

-- // trust start
function GeneralTrustCommands:handle_start(_, include_party)
    local success = true
    local message

    self.addon_enabled:setValue(true)

    if include_party then
        message = "Trust started on all characters"
        IpcRelay.shared():send_message(CommandMessage.new('trust start'))
    else
        message = "Trust started"
    end

    return success, message
end

-- // trust startall [party]
function GeneralTrustCommands:handle_start_all(_, ...)
    return self:handle_all(_, 'start', ...)
end

-- // trust stop
function GeneralTrustCommands:handle_stop(_, include_party)
    local success = true
    local message

    self.addon_enabled:setValue(false)

    if include_party then
        message = "Trust stopped on all characters"
        IpcRelay.shared():send_message(CommandMessage.new('trust stop'))
    else
        message = "Trust stopped"
    end

    return success, message
end

-- // trust stopall [party]
function GeneralTrustCommands:handle_stop_all(_, ...)
    return self:handle_all(_, 'stop', ...)
end

function GeneralTrustCommands:handle_all(_, command, ...)
    local scope = select(1, ...)
    local argument_count = select('#', ...)
    if argument_count > 1 or (argument_count == 1 and (type(scope) ~= 'string' or scope:lower() ~= 'party')) then
        return false, 'Usage: // trust '..command..'all [party]'
    end

    local handler = self['handle_'..command]
    if argument_count == 0 then
        return handler(self, _, true)
    end

    local success, message = handler(self, _)
    local player_name = windower.ffxi.get_player().name
    for party_member_name in party_util.get_party_member_names(false):it() do
        if party_member_name and party_member_name ~= '' and party_member_name ~= player_name then
            IpcRelay.shared():send_message(CommandMessage.new('trust '..command, party_member_name))
        end
    end

    return success, message..' on party members'
end

-- // trust toggle
function GeneralTrustCommands:handle_toggle(_)
    local success = true
    local message = "Trust stopped"

    if self.addon_enabled:getValue() then
        success, message = self:handle_stop(_)
    else
        success, message = self:handle_start(_)
    end

    return success, message
end

-- // trust reload
function GeneralTrustCommands:handle_reload(_)
    local success = true
    local message

    self.main_trust_settings:loadSettings()
    self.sub_trust_settings:loadSettings()

    return success, message
end

-- // trust set mode_name mode_value
function GeneralTrustCommands:handle_set_mode(_, mode_name, mode_value)
    local success = true
    local message

    handle_set(mode_name, mode_value)

    return success, message
end

-- // trust cycle mode_name
function GeneralTrustCommands:handle_cycle_mode(_, mode_name)
    local success = true
    local message

    handle_cycle(mode_name)

    return success, message
end

-- // trust load mode_set_name
function GeneralTrustCommands:handle_load_set(_, mode_set_name)
    local success
    local message

    if not mode_set_name then
        success = false
        message = "Invalid mode set name"
    else
        success = true

        state.TrustMode:set(mode_set_name)
    end

    return success, message
end

-- // trust save or // trust save mode_set_name
function GeneralTrustCommands:handle_save_set(_, mode_set_name)
    local success = true
    local message

    trust_mode_settings:saveSettings(mode_set_name or state.TrustMode.value)

    addon_system_message(string.format("Saved profile %s.", mode_set_name or state.TrustMode.value))

    return success, message
end

-- // trust timeout num_minutes or // trust timeout clear
function GeneralTrustCommands:handle_timeout(_, num_minutes)
    local success
    local message

    if num_minutes == nil then
        success = false
        message = string.format("Valid options are clear or number of minutes")
    else
        success = true
        if num_minutes == 'clear' then
            _addon.timeout = nil
            message = "Timeout cleared"
        else
            _addon.timeout = tonumber(num_minutes)
            message = string.format("Trust will unload after %d minutes", num_minutes)
        end
    end

    return success, message
end

-- // trust item item_name
function GeneralTrustCommands:handle_use_item(_, ...)
    local item_name = table.concat({...}, " ") or ""
    item_name = windower.convert_auto_trans(item_name)
    if item_name == nil then
        return false, "Invalid item name"
    end

    local CommandAction = require('cylibs/actions/command')
    self.action_queue:push_action(CommandAction.new(0, 0, 0, '/item "' .. item_name .. '" <me>'), true)

    return true, "Using " .. item_name
end

-- // trust debug
function GeneralTrustCommands:handle_debug()
    local mob = windower.ffxi.get_mob_by_name("Pulse Martello")
    print(mob.name, mob.is_npc, mob.entity_type, mob.in_party, mob.in_alliance, mob.valid_target)



    --local EquipSetAction = require('cylibs/actions/equip_set')
    --local EquipSet = require('cylibs/inventory/equipment/equip_set')
    --local EquipSet = require('cylibs/battle/equip_set')
    --local EquipSets = require('settings/settings').EquipSet

    --local equipSet = EquipSet.new('test_set')
    --if Condition.check_conditions(equipSet:get_conditions(), windower.ffxi.get_player().index) then
    --print('is valid')
    --local action_queue = ActionQueue.new(nil, false, 5)
    --action_queue:push_action(equipSet:to_action(windower.ffxi.get_player().index), true)
    --else
    --print('is not valid')
    --end

    --[[local Inventory = require('cylibs/inventory/inventory')
    local inventory = Inventory.new()

    local bag, index = inventory:find(22062)

    print(res.bags:with('api', bag.name).id, index)]]

    --print(inventory:find(22062))
    --print(inventory:find(23691))

    return true, nil
end

return GeneralTrustCommands